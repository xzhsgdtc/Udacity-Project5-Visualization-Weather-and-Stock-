# P6 Make Effective Data Visualization 
## Zihe Xu
##### Summary: In this project, I visualized the US stock market data (SP500 index) combined with the Weather data for New York. The weather data contains the Highs and Lows for New York as well as 15 kind of bad weather. I analyzed the weather data independently at first, Using 7-Day-Average, there is a clear circular pattern for the temperature, also I found that in year between 2013 and 2015, the number of bad weather is smaller than other years. And it seems the bad weather will have some influence to the market given that a lot of bad weather recorded when the market is at its local minimum.

### 1. Find and clean the data
#### 1.1 Find data and basic attributes of the data
For this project, I used the last 5 years of SP500 data from Yahoo Finance and the Weather data for New York from NOAA.\
The Finance data contains:
 -  Date ( 2015-07-24)
 -  Open (The index when market opened)
 -  Close(The index when market closed)
 -  High ( The highest value of that day)
 -  Low( The lowest value of that day)
 -  Volume(The total volume of transactions made)
 -  Adj Close(Close price accounts for all corporate actions)
 
The Weather data comes from one station: NEW YORK CENTRAL PARK OBS BELVEDERE TOWER NY US. \
The weather data contains:
- Date - six numerical numbers(20150101)
- WT01 - Fog, ice fog, or freezing fog (may include heavy fog)
- WT02 - Heavy fog or heaving freezing fog (not always distinguished from fog)
- WT04 - Ice pellets, sleet, snow pellets, or small hail" 
- WT05 - Hail (may include small hail)
- WT06 - Glaze or rime 
- WT07 - Dust, volcanic ash, blowing dust, blowing sand, or blowing obstruction
- WT08 - Smoke or haze 
- WT09 - Blowing or drifting snow
- WT11 - High or damaging winds
- WT13 - Mist
- WT14 - Drizzle
- WT16 - Rain (may include freezing rain, drizzle, and freezing drizzle)" 
- WT17 - Freezing rain - 
- WT18 - Snow, snow pellets, snow grains, or ice crystals
- WT19 - Unknown source of precipitation 
- WT22 - Ice fog or freezing fog
- TMIN - Minimum temperature (tenths of degrees C)
- TMAX - Maximum temperature (tenths of degrees C) 

I also download the London weather data, however I found about half of the data is -9,999 which means null indicated by the NOAA's documentation. So I didn't include that. 
#### 1.2 Clean the data 
For the finance data, it's pretty good, I didn't find any singularities. I can use excel to get the date( Year, Month, Day) from the data.\
For the weather data:\
- 1. There are a lot of -9,999 in all columns starts from WT*, it means null or not happened. So I simply use find and replace in excel to replace all of those with 0.\
- 2. I Changed the column name from WT* to words reflect the meaning of that column. \
- 3. The data format is not standard for excel, I use the LEFT,RIGHT and MID method in excel to get the year,month,day independently and append them to the same date form with the finace data for later process.\


#### 1.3 Data Processing 
First notice most of the WT* means some kind of a bad weather, and normally 90% of them is 0, so I decide to add a new feature to indicate how bad the weather was by sum up all the possible bad weather and get a column called "BadWeather"
Noticing that the Finance data doesn't contain 365 in a year because it doesn't have any data during the weekends or holidays.Therefore simply connect those two data sequentially is not possible. In the past I will write a python code to read csv loop over all data and write to a result file, but this time some of my friend told me an easier way to do this, simply use the excel's build in LOOKUP function, it works very well, and because our data set is not that large, it's actually much faster than write a script. Use this method, I joined the weather data and the stock price date with the TMAX,TMIN,BadWeather columns.  Also I Add columns for daily average 1/2(High + Low),3 day average and 7 day average, when plot those values, I found 7 day average provide most smooth lines. 

### Design
First for the temperature, I choose to use line and circles to represent them as the position is the most accurate visual encoding, I also use color and size to distinguish the good weather and the bad weather, if there is no bad weather you will see a blue circle. The size will reflect how bad the weather is, here when I have more type of bad weather recorded, I will have a larger value for measure how bad the weather is. \
For the Bad weather, I use a bar chart to look into it, because all of them are integers between 0 to 10, so a bar chart is better than a line chart. 
For the Stock, I choose use the line chart to represent the closing value, and use the size to represent the volume of stocks that being traded.  Also I tried to use color to indicate the bad weather when combine the two data set, and use animation to view them year by year to get a more clear view. When presenting the final result I add opacity because of the overlaps. 
### Feedback
For Sketch 1, my friend thinks it is too many points overlapping each other, and because only one variable used, so there is no need to use a red color on them.
For Sketch 2, the feedback I get is there seems no strong difference between two colors, it might be better to study the bad weather independently. So I made another graph use bar chart to look into the bad weather and found in 2013 there is significantly smaller number of bad weather comparing to all other years. 
For Sketch 3, too many overlap, and the color doesn't indicate the weather, so I add transition by year to get a clear view. For Sketch 4, it seems the temperature doesn't related to the stock's' value much, so I changed that to the number of bad weathers in the final one. 

### Resources
- [National Centers for Environmental Information](http://www.ncdc.noaa.gov/)
- [Yahoo Finance](http://finance.yahoo.com/)


